﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace TARge20.Core.Domain
{
    public class Kitchen
    {
        [Key]
        public Guid Id { get; set; }
        public int Menu_ID { get; set; }
        public string Cook_ID { get; set; }
    }
}
