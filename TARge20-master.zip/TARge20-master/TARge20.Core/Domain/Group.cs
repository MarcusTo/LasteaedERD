﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace TARge20.Core.Domain
{
    public class Group
    {
        [Key]
        public Guid Id { get; set; }
        public int Group_ID { get; set; }
        public string GroupType { get; set; }
        public string EatingHistory{ get; set; }
    }
}
