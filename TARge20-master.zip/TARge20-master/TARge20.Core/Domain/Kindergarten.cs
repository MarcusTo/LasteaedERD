﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TARge20.Core.Domain
{
    public class Kindergarten
    {
        [Key]
        public Guid Id { get; set; }
        public int Educator_ID { get; set; }
        public int Group_ID { get; set; }
        public int Children_ID { get; set; }
        public string Name { get; set; }
        public string Adress { get; set; }
    }
}
