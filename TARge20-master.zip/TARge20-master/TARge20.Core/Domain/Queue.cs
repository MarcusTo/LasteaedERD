﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
namespace TARge20.Core.Domain
{
    public class Queue
    {
        [Key]
        public Guid Id { get; set; }
        public int Children_ID { get; set; }
        public int Group_ID { get; set; }
        public int QueuePosition { get; set; }
    }
}
