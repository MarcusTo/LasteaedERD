﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace TARge20.Core.Domain
{
    public class Group_History
    {
        [Key]
        public Guid Id { get; set; }
        public int GroupHistory_ID { get; set; }
        public int Group_ID { get; set; }
        public int StartDate { get; set; }
        public int EndDate { get; set; }

    }
}
