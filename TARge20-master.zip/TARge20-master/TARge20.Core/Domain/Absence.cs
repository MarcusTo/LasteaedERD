﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace TARge20.Core.Domain
{
    public class Absence
    {
        [Key]
        public Guid Id { get; set; }
        public string Absence_ID { get; set; }
        public int Date { get; set; }
        public string Reason { get; set; }
    }
}
