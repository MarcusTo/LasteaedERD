﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
namespace TARge20.Core.Domain
{
    public class Working_History
    {
        [Key]
        public Guid Id { get; set; }
        public int WorkingHistory_ID { get; set; }
        public string Educator_ID { get; set; }
        public int Group_ID { get; set; }
        public int Children_ID { get; set; }
        public string Name { get; set; }
        public string Adress { get; set; }
    }
}
