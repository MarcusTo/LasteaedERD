﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace TARge20.Core.Domain
{
    public class Menu
    {
        [Key]
        public Guid Id { get; set; }
        public string Meals { get; set; }
        public int Date { get; set; }

    }
}
